import { useEffect, useRef, useState } from 'react'
import { schedule, news, roles, patrons, exec, sponsors, years, videos } from './data.js'

const START = new Date('2026-10-16T00:00:00+05:30')
const END = new Date('2026-10-22T00:00:00+05:30')
const links = [['news','News'],['schedule','Schedule'],['bhog','Bhog'],['gallery','Gallery'],['committee','Committee'],['donate','Donate'],['sponsors','Sponsors']]

function useCountdown() {
  const [now, setNow] = useState(Date.now())
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(t) }, [])
  const ms = START - now
  return { ms, live: now >= START && now < END, over: now >= END,
    d: Math.floor(ms / 864e5), h: Math.floor(ms % 864e5 / 36e5), m: Math.floor(ms % 36e5 / 6e4), s: Math.floor(ms % 6e4 / 1e3) }
}

function useReveal() {
  const ref = useRef(null)
  useEffect(() => {
    const el = ref.current; if (!el) return
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { el.classList.add('in'); io.disconnect() } }, { threshold: 0.12 })
    io.observe(el); return () => io.disconnect()
  }, [])
  return ref
}
const Section = ({ id, title, bn, children }) => {
  const ref = useReveal()
  return <section id={id} ref={ref} className="sec reveal"><h2>{title}<span>{bn}</span></h2>{children}</section>
}

function Nav() {
  const [active, setActive] = useState('news')
  useEffect(() => {
    const io = new IntersectionObserver(es => es.forEach(e => e.isIntersecting && setActive(e.target.id)), { rootMargin: '-45% 0px -50% 0px' })
    links.forEach(([id]) => { const el = document.getElementById(id); el && io.observe(el) })
    return () => io.disconnect()
  }, [])
  return <nav>{links.map(([id, t]) => <a key={id} href={'#' + id} className={active === id ? 'on' : ''}>{t}</a>)}</nav>
}

function Hero() {
  const c = useCountdown()
  return <header className="hero">
    <div className="bg" />
    <div className="glow" />
    <div className="inner">
      <p className="kicker">ওঁ নমঃ শ্রী দুর্গায়ৈ · Est. 1999 · 28th Year</p>
      <h1>North Zone Sarbojanin<br />Durga Puja Committee</h1>
      <p className="sub">Uliyan Main Road, Kadma, Jamshedpur. Shardiya Durga Puja 2026, 16 to 21 October.</p>
      {c.live ? <p className="live">Shubho Puja! The celebrations are on right now.</p>
       : c.over ? <p className="live">Thank you for celebrating with us. Shubho Bijoya!</p>
       : <div className="cd">{[['d','days'],['h','hours'],['m','min'],['s','sec']].map(([k, l]) => <div key={k}><b>{String(c[k]).padStart(2, '0')}</b><span>{l}</span></div>)}</div>}
      {!c.live && !c.over && <p className="sub">until Mahashashthi</p>}
      <div className="cta"><a href="#schedule" className="btn gold">Puja schedule</a><a href="#donate" className="btn">Donate</a></div>
    </div>
  </header>
}

function Schedule() {
  const today = new Date().toISOString().slice(0, 10)
  const first = Math.max(0, schedule.findIndex(s => s.date >= today))
  const [i, setI] = useState(first)
  const s = schedule[i]
  const fmt = d => new Date(d + 'T00:00:00').toLocaleDateString('en-IN', { day: 'numeric', month: 'short' })
  return <div className="sched">
    <div className="days" role="tablist">{schedule.map((x, k) =>
      <button key={x.date} role="tab" aria-selected={k === i} className={k === i ? 'on' : ''} onClick={() => setI(k)}>
        <b>{fmt(x.date)}</b><span>{x.name}</span></button>)}</div>
    <div className="detail" key={s.date}>
      <h3>{s.name} <em>{s.bn}</em></h3><p className="day">{s.day}, {fmt(s.date)} 2026</p><p>{s.text}</p>
    </div>
    <p className="note">Purohit: Sri Goutam Banerjee, <a href="tel:9931121642">9931121642</a>, <a href="tel:9334671832">9334671832</a>. Confirm exact timings at the pandal.</p>
  </div>
}

function Tile({ src, label, onOpen }) {
  const [bad, setBad] = useState(false)
  return bad ? <div className="ph">{label}<br /><small>add photo</small></div>
    : <button className="tile" onClick={() => onOpen(src)}><img src={src} alt={label} loading="lazy" onError={() => setBad(true)} /></button>
}
function Gallery() {
  const [y, setY] = useState(years[0]); const [big, setBig] = useState(null)
  useEffect(() => { const k = e => e.key === 'Escape' && setBig(null); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [])
  return <>
    <div className="tabs">{years.map(v => <button key={v} className={v === y ? 'on' : ''} onClick={() => setY(v)}>{v}</button>)}</div>
    <div className="gal">{[1, 2, 3, 4, 5, 6].map(n => <Tile key={y + n} src={`/images/gallery/${y}/${n}.jpg`} label={`Puja ${y}`} onOpen={setBig} />)}</div>
    <h3 className="h3">Videos</h3>
    <div className="gal vids">{videos.length ? videos.map(v => <iframe key={v} src={`https://www.youtube.com/embed/${v}`} title="Puja video" allowFullScreen loading="lazy" />)
      : [1, 2, 3].map(n => <div className="ph v" key={n}>Video {n}<br /><small>add YouTube ID in data.js</small></div>)}</div>
    {big && <div className="lb" onClick={() => setBig(null)}><img src={big} alt="Enlarged puja photo" /></div>}
  </>
}

function Donate() {
  const [f, setF] = useState({ n: '', p: '', a: '', u: 'General donation' }); const [msg, setMsg] = useState('')
  const set = k => e => setF({ ...f, [k]: e.target.value })
  const submit = e => { e.preventDefault(); setMsg(`Donation pledge, North Zone Sarbojanin Durga Puja 2026\nName: ${f.n}\nPhone: ${f.p}\nAmount: ₹${f.a}\nPurpose: ${f.u}\nShare with treasurer: Sri Goutam Dey or Sri Suvendu Das.`) }
  return <div className="donate">
    <p>Your donation funds the idol, decoration, bhog and cultural programmes. Pledge below, then hand the message to a treasurer.</p>
    <form onSubmit={submit}>
      <label>Name<input required value={f.n} onChange={set('n')} /></label>
      <label>Phone<input required type="tel" value={f.p} onChange={set('p')} /></label>
      <label>Amount (₹)<input required type="number" min="1" value={f.a} onChange={set('a')} /></label>
      <label>Purpose<select value={f.u} onChange={set('u')}><option>General donation</option><option>Bhog and prasad</option><option>Decoration and pandal</option><option>Cultural programme</option></select></label>
      <button className="btn gold">Create pledge message</button>
    </form>
    {msg && <><pre className="msg">{msg}</pre><button className="btn out" onClick={() => navigator.clipboard?.writeText(msg)}>Copy message</button></>}
    <p className="note">Add the committee\u2019s UPI or bank details here before going live.</p>
  </div>
}

export default function App() {
  return <>
    <Nav />
    <Hero />
    <Section id="news" title="News" bn="খবর"><div className="grid">{news.map(([t, d]) => <div className="card" key={t}><h3>{t}</h3><p>{d}</p></div>)}</div></Section>
    <Section id="schedule" title="Puja Schedule and Tithi" bn="পূজার সময়সূচী"><Schedule /></Section>
    <section id="bhog" className="bhog"><b>Bhog: 1 PM to 3 PM</b><p>ভোগ বিতরণ প্রত্যহ দুপুর ১টা হইতে ৩টা · Ashtami thali by 3 PM</p><p>Licence holder: Sri Anup Roy · Licence No. 17/2013</p></section>
    <Section id="gallery" title="Photos and Videos" bn="স্মৃতির অ্যালবাম"><Gallery /></Section>
    <Section id="committee" title="Committee" bn="কমিটি">
      <div className="roles">{roles.map(([r, n]) => <div key={r}><small>{r}</small>{n.map(x => <b key={x}>{x}</b>)}</div>)}</div>
      <h3 className="h3">Patrons</h3><ul className="names">{patrons.map(x => <li key={x}>{x}</li>)}</ul>
      <h3 className="h3">Executive Committee</h3><ul className="names">{exec.map(x => <li key={x}>{x}</li>)}</ul>
      <h3 className="h3">In loving memory</h3>
      <div className="grid"><div className="card mem"><h3>Late Jitendra Nath Majumdar</h3><p>Ex. Executive Member · 1940 to 2025</p></div><div className="card mem"><h3>Late Ghashuram Mahato</h3><p>Ex. Deputy Patron in Chief · 1945 to 2026</p></div></div>
    </Section>
    <Section id="donate" title="Donation" bn="চাঁদা / দান"><Donate /></Section>
    <Section id="sponsors" title="Our Sponsors" bn="বিজ্ঞাপনদাতা"><div className="grid">{sponsors.map(([t, d, p]) =>
      <div className="card" key={t}><h3>{t}</h3><p>{d}</p><p>{p.map((x, k) => <span key={x}>{k > 0 && ' · '}<a href={'tel:' + x}>{x}</a></span>)}</p></div>)}</div></Section>
    <footer><b>North Zone Sarbojanin Durga Puja Committee</b><br />Uliyan Main Road, Kadma, Jamshedpur – 831005<br />Sri Sri Shardiya Durga Puja 2026 · 28th Year</footer>
  </>
}
