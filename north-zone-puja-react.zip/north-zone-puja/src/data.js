export const schedule = [
 { date:'2026-10-16', name:'Mahashashthi', bn:'মহাষষ্ঠী', day:'Friday', text:'Shashthi tithi till 3:47 AM (night). Shashthi kalparambha and puja. Devi\u2019s amantran and adhivas in the evening.' },
 { date:'2026-10-17', name:'Mahasaptami', bn:'মহাসপ্তমী', day:'Saturday', text:'Saptami begins 7:04 AM. Navapatrika pravesh, sthapan, Saptami kalparambha and puja before noon. Devi arrives on a horse (fruit: chhatrabhanga).' },
 { date:'2026-10-18', name:'Saptami puja', bn:'সপ্তমী', day:'Sunday', text:'Saptami tithi till 5:53 AM. Additional Saptami puja.' },
 { date:'2026-10-19', name:'Mahashtami', bn:'মহাষ্টমী', day:'Monday', text:'Ashtami tithi till 7:50 AM. Kalparambha, puja and vrat. Sandhi Puja: begins 7:26, bali 7:50, ends 8:14 (as printed in the souvenir). Collect Ashtami prasad thali by 3 PM.' },
 { date:'2026-10-20', name:'Mahanavami', bn:'মহানবমী', day:'Tuesday', text:'Navami tithi till 9:31 AM. Navami kalparambha and puja before noon.' },
 { date:'2026-10-21', name:'Vijayadashami', bn:'বিজয়াদশমী', day:'Wednesday', text:'Dashami tithi till 10:47 AM. Dashami puja, then visarjan. Aparajita puja and Vijayadashami rituals follow. Devi departs by boat (prosperity of crops and water).' },
 { date:'2026-10-25', name:'Lakshmi Puja', bn:'কোজাগরী লক্ষ্মী পূজা', day:'Sunday', text:'Kojagari Lakshmi Puja.' },
 { date:'2026-11-08', name:'Kali Puja', bn:'শ্যামা পূজা', day:'Sunday', text:'Kali Puja / Deepavali. Amavasya begins 10:48 AM.' },
]
export const news = [
 ['28th year of celebration','Est. 1999, the committee celebrates Durga Puja from 16 to 21 October 2026.'],
 ['Pratima donated by Pankaj Baidya','This year\u2019s idol of Maa Durga is donated by Sri Pankaj Baidya, Deputy Patron in Chief.'],
 ['Devi comes on a horse, leaves by boat','Arrival on a horse (chhatrabhanga), departure by boat (prosperity of crops and water).'],
 ['Cultural programmes','The programme will be announced at the puja pandal.'],
 ['Bhog 1 PM to 3 PM','Ashtami prasad thali must be collected by 3 PM.'],
 ['Everyone is invited','Across caste, religion and community, join us with family and friends.'],
]
export const roles = [
 ['Patron in Chief',['Sri Sudipto Mukherjee']],
 ['Deputy Patrons in Chief',['Sri Pankaj Baidya','Sri Jitu Verma']],
 ['President',['Sri Indrajit Ghosh']],
 ['Working President',['Sri Taposh Paul']],
 ['General Secretary',['Sri Sisir Dey']],
 ['Treasurers',['Sri Goutam Dey','Sri Suvendu Das']],
 ['Secretaries',['Sri Anup Roy','Sri Arup Roy','Sri Debashish Chakraborty']],
 ['Auditor',['Sri Nagendra Nath Mukhi']],
]
export const patrons = ['Sri Suraj Bhadani','Sri Birendra Kr. Pandey','Sri Biswanath Roy','Sri Ghasu Ram Mahato','Sri Parijat Dutta','Sri Hari Subromanium','Sri Manoj Kumar','Sri Arun Tiwary','Sri Santosh Agarwal','Sri Sukumar Bose','Sri Santosh Kr. Gupta']
export const exec = ['Sri Sonu Singh','Sri Pijus Mitra','Sri A. Dutta Roy','Sri Nishit Giri','Sri Sajal Roy','Sri Habul Banerjee','Sri Aswani Das','Sri Sukhdeo Raj Singh','Sri Jhantu Mallick','Sri P. C. Mohanty','Sri Utpal Choudhary','Sri N. K. Srivastava (Putu)','Sri Ashish Kundu','Sri B. K. Sharma','Sri Utpal Chatterjee','Sri Sandeep Dey','Sri V. Srinivas Rao (Chintu)','Sri Prasanjit Das (Titu)','Sri Sourav Das','Sri Ram Krishna Nayak','Sri Debashish Barua','Sri Deo Nandan Sharma']
export const sponsors = [
 ['Gandhi College','B.Pharma, D.Pharma, Nursing, GNM, ANM, DMLT, ITI. Sijulata (Seraikela), Asangi and Bhatia (Adityapur).',['8789000378','9661801271']],
 ['Purnima Medical','Chemist & druggist. 20% off medicines, free home delivery up to 3 km. Uliyan Main Road, Kadma.',['6203628609']],
 ['MJ Jewellers · MJ Cosmo+','91.6 gold and silver jewellery, cosmetics. Kadma and Hi-Tech City Center Mall, Bistupur.',['8409144711','9835571265','7209545251']],
 ['R R Solutions','SF Batteries and Eureka Forbes Aquaguard dealer. Shiv Usha Complex, Kadma.',['9708566512','7004502371','9661815013']],
 ['Aami Bangali Restaurant','Authentic Bengali cuisine. B Road, West Layout, Sonari.',['6200074750']],
 ['Sportistry','Football jerseys, boots and custom kits. Safia Complex, Sakchi. @sportistry.jsr',['8292722414']],
 ['Natures Harvest','Oyster and paddy mushroom growing and supply. Naturally grown, chemical free.',['7488366464']],
 ['Contact Point','Anup Roy (Chotku). All types of vehicle paper work. Bajrang Akhara, Kadma.',['9263972597','9334085325']],
]
export const years = ['2025','2024','2023','2022']
// Add YouTube video IDs here, e.g. ['dQw4w9WgXcQ']
export const videos = []
