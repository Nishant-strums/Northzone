# North Zone Sarbojanin Durga Puja Committee, website
Local: `npm install` then `npm run dev`
Deploy: push to GitHub, import in Vercel (Framework: Vite, auto-detected). Build: `npm run build`, output: `dist`.
Photos: see public/images/README.txt. Videos and text: src/data.js
