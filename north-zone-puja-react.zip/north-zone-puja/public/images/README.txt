PUT YOUR PHOTOS HERE
1. durga-bg.jpg  -> main hero background (wide photo of Maa Durga pratima, min 1600px wide)
2. gallery/2025/1.jpg ... 6.jpg (same for 2024, 2023, 2022) -> past year photos
Missing files fall back to a placeholder automatically.
